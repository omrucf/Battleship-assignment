/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignment_2;

/**
 *
 * @author Mohammed Ayoub
 */
public class Assignment_2 {
    public static void main(String[] args) {
        // Launch the Battleship game
        Battleship game = new Battleship();
    }
}